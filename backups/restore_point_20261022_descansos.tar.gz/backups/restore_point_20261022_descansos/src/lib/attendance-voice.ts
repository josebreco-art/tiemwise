'use client';

/**
 * Asistente de voz (Text-to-Speech) para confirmación de asistencia
 */

export interface SpeakAttendanceParams {
  name: string;
  type: 'entrada' | 'salida' | 'almuerzo_inicio' | 'almuerzo_fin';
  time?: Date;
  locationName?: string;
  enabled?: boolean;
}

export function formatTimeForVoice(date: Date = new Date()): string {
  try {
    return date.toLocaleTimeString('es-CR', {
      hour: 'numeric',
      minute: '2-digit',
      hour12: true,
    });
  } catch {
    const hours = date.getHours();
    const minutes = String(date.getMinutes()).padStart(2, '0');
    const ampm = hours >= 12 ? 'de la tarde' : 'de la mañana';
    const formattedHour = hours % 12 || 12;
    return `${formattedHour}:${minutes} ${ampm}`;
  }
}

export function speakAttendance({
  name,
  type,
  time = new Date(),
  locationName,
  enabled = true,
}: SpeakAttendanceParams): { message: string; supported: boolean } {
  const formattedTime = formatTimeForVoice(time);
  const firstName = name.trim().split(' ')[0] || name;

  let message = '';
  switch (type) {
    case 'entrada':
      message = `¡Bienvenido, ${firstName}! Tu ENTRADA ha sido registrada con éxito a las ${formattedTime}${
        locationName ? ` en ${locationName}` : ''
      }. ¡Que tengas un excelente día de trabajo!`;
      break;
    case 'salida':
      message = `¡Hasta luego, ${firstName}! Tu SALIDA ha sido registrada con éxito a las ${formattedTime}. ¡Buen descanso y gracias por tu labor!`;
      break;
    case 'almuerzo_inicio':
      message = `¡Buen provecho, ${firstName}! Tu salida a almuerzo ha sido registrada a las ${formattedTime}.`;
      break;
    case 'almuerzo_fin':
      message = `¡Bienvenido nuevamente, ${firstName}! Tu regreso de almuerzo ha sido registrado a las ${formattedTime}.`;
      break;
    default:
      message = `Registro completado para ${firstName} a las ${formattedTime}.`;
  }

  if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
    return { message, supported: false };
  }

  if (!enabled) {
    return { message, supported: true };
  }

  try {
    // Cancel any pending speech
    window.speechSynthesis.cancel();

    const utterance = new SpeechSynthesisUtterance(message);
    utterance.lang = 'es-ES';
    utterance.rate = 0.95;
    utterance.pitch = 1.0;
    utterance.volume = 1.0;

    // Pick Spanish voice if available
    const voices = window.speechSynthesis.getVoices();
    const spanishVoice = voices.find(
      (v) =>
        v.lang.startsWith('es') ||
        v.lang.includes('es-ES') ||
        v.lang.includes('es-MX') ||
        v.lang.includes('es-US') ||
        v.lang.includes('es-419')
    );

    if (spanishVoice) {
      utterance.voice = spanishVoice;
    }

    window.speechSynthesis.speak(utterance);
  } catch (err) {
    console.warn('Speech synthesis error:', err);
  }

  return { message, supported: true };
}

export function testVoiceBot(): void {
  if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(
      '¡Hola! El asistente de voz está listo y configurado para confirmar entradas y salidas.'
    );
    utterance.lang = 'es-ES';
    utterance.rate = 0.95;
    utterance.pitch = 1.0;

    const voices = window.speechSynthesis.getVoices();
    const spanishVoice = voices.find((v) => v.lang.startsWith('es'));
    if (spanishVoice) {
      utterance.voice = spanishVoice;
    }

    window.speechSynthesis.speak(utterance);
  }
}
